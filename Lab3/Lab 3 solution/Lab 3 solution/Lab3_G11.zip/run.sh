python3 Lab_3_solution.py
